# Flask-To-Do-List


Install the necessary tools

```python
pip install -r requirements.txt
```

run main.py to start the project
